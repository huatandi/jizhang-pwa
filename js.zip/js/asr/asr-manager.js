'use strict';
/**
 * AsrKit · asr-manager —— ASR 编排层（主引擎 + 回退 + 状态机）
 *
 * 策略（与 OCR 对称）：
 *   PRIMARY: Whisper（本地，离线）
 *   FALLBACK: Web Speech API（仅当用户显式允许「在线语音」且 Whisper 不可用时）
 *
 * 对外状态机事件（与旧 VoiceSR 协议一致）：
 *   onInterim(text)  onFinal(text)  onError(code)  onEnd()
 *   onState(state)  onLevel(rms)  onModelProgress(progress)
 */
(function (global) {
  const ERR = global.AsrKit.ERRORS;

  // 默认 ASR 语言（BCP-47）：优先 global-config 检测，兜底浏览器语言
  function defaultAsrBcp47() {
    try {
      const gc = global.AIKit && global.AIKit.globalConfig;
      if (gc && gc.detectLang) {
        const l = gc.detectLang();
        if (l) return l;
      }
    } catch (e) { /* ignore */ }
    try {
      const nav = global.navigator || {};
      return nav.language || 'en-US';
    } catch (e) { return 'en-US'; }
  }

  class AsrManager {
    constructor(opts) {
      this.opts = opts || {};
      this.lang = this.opts.lang || defaultAsrBcp47();
      this.engine = null;
      this.capture = null;
      this.vad = null;
      this.active = false;
      this.allowOnline = !!this.opts.allowOnline;   // 用户显式授权在线回退
      this.mode = null; // 'local' | 'online'
      this.cb = null;
      this.audioQueue = [];
      this._speaking = false;   // 是否正在推理（防并发）
      this._hasPendingUtterance = false;
    }

    setCallback(cb) { this.cb = cb || {}; }
    setLang(lang) { this.lang = lang || defaultAsrBcp47(); }

    /** V5 Phase1 保险13/14：隐私门——LOCAL_ONLY 模式下本地失败也绝不启用 WebSpeech(在线) */
    _privacyAllowsOnline() {
      try {
        const P = global.AIPrivacy;
        if (P && typeof P.getMode === 'function') return P.getMode() !== 'local_only';
      } catch (e) { /* ignore */ }
      return true;
    }

    _emit(name, payload) {
      if (this.cb && typeof this.cb[name] === 'function') {
        try { this.cb[name](payload); } catch (e) { console.error('[asr] cb error:', e); }
      }
    }

    /** 后端能力检测（不触发初始化） */
    static capability() {
      return {
        whisperPossible: true, // 是否能跑，取决于 wasm/webgpu 与内存
        webspeech: global.AsrKit.webspeechSupported,
        webgpu: !!(global.navigator && global.navigator.gpu),
      };
    }

    /** 选择引擎：本地优先，失败降级在线（需授权）；forceOnline 时直接在线 */
    async _selectEngine() {
      // forceOnline：跳过 Whisper（含已缓存的 local mode），直接 WebSpeech。
      // ⚠️ 隐私门：LOCAL_ONLY 下即使 forceOnline 也绝不启用在线（V5 保险13）。
      if (this.opts.forceOnline) {
        if (this._privacyAllowsOnline() && global.AsrKit.webspeechSupported) {
          this.engine = new global.AsrKit.WebSpeechEngine();
          this.mode = 'online';
          return this.engine;
        }
        const err = new Error(ERR.ASR_FAILED);
        if (!this._privacyAllowsOnline()) err.privacyBlocked = true;
        throw err;
      }
      if (this.mode === 'local') return this.engine;

      // 本地 Whisper
      // V5 Phase1 保险7：设备级熔断——连续多次初始化失败 → 暂不健康,直接走允许的 fallback
      const cb = global.AsrKit.circuitBreaker;
      if (cb && cb.isDisabled('whisper')) {
        console.warn('[asr] Whisper 当前被熔断(连续失败),直接走 fallback');
        if (this.allowOnline && this._privacyAllowsOnline() && global.AsrKit.webspeechSupported) {
          this.engine = new global.AsrKit.WebSpeechEngine();
          this.mode = 'online';
          return this.engine;
        }
        const err = new Error(ERR.ASR_FAILED);
        if (!this._privacyAllowsOnline()) err.privacyBlocked = true;
        throw err;
      }
      const WhisperEngine = global.AsrKit.WhisperEngine;
      const profile = global.AsrKit.modelManager.detectProfile();
      let plan = global.AsrKit.modelManager.resolvePlan(profile, this.opts.modelForce);
      // 内存不够 → 降级到能跑动的档位（而非 emit 后继续用原 plan 导致 OOM 崩溃）
      if (!global.AsrKit.modelManager.fitsMemory(plan)) {
        const tiny = global.AsrKit.modelManager.resolvePlan('low');
        if (global.AsrKit.modelManager.fitsMemory(tiny)) {
          plan = tiny;
          this._emit('onError', ERR.OUT_OF_MEMORY);
        }
      }
      try {
        this.engine = new WhisperEngine({
          device: this.opts.device || 'auto',
          dtype: plan.dtype,
          modelRepo: plan.baseRepo,
          language: this.lang.split('-')[0],
          wasmPaths: this.opts.wasmPaths,
          onProgress: (p, l) => this._emit('onModelProgress', { progress: p, label: l }),
        });
        this.mode = 'local';
        return this.engine;
      } catch (e) {
        console.warn('[asr] Whisper 初始化失败:', e);
        this.mode = null; // 防止 mode 残留 'local'
      }

      // 回退：在线（需授权 + 隐私门：LOCAL_ONLY 绝不启用）
      if (this.allowOnline && this._privacyAllowsOnline() && global.AsrKit.webspeechSupported) {
        this.engine = new global.AsrKit.WebSpeechEngine();
        this.mode = 'online';
        return this.engine;
      }
      const err = new Error(ERR.ASR_FAILED);
      err.cause = e;
      // 隐私门导致的失败：明确标记，避免"本地失败→静默在线"掩盖隐私策略
      if (!this._privacyAllowsOnline()) err.privacyBlocked = true;
      throw err;
    }

    /** 开始连续识别（VAD + Whisper / WebSpeech 伪连续） */
    async start() {
      // ⚠️ 竞态修复：start() 必须串行化。
      // 旧实现 `if (this.active) return;` 会吞掉"上一轮 stop 尚未完成时的新 start"，
      // 导致 iOS 单次识别 end→restart 时识别器实际未启动（用户只能说一句）。
      // 现在：启动中→复用同一 Promise；已在监听→先完整 stop 再 start。
      if (this.starting) return this.startPromise;
      if (this.active) { await this.stop(); }
      this.starting = true;
      this.startPromise = this._startInternal();
      try {
        await this.startPromise;
      } finally {
        this.starting = false;
        this.startPromise = null;
      }
    }

    async _startInternal() {
      this.active = true;
      try {
        this.engine = await this._selectEngine();
        if (!this.active) return; // 启动期间被 stop → 放弃（stop() 已清理资源）

        // 在线模式：直接走 WebSpeech 事件流（引擎内部自动续听，end 只在用户停止时上报）
        if (this.mode === 'online') {
          this.engine.setCallback((ev) => {
            if (ev.interim) this._emit('onInterim', ev.interim);
            if (ev.final) this._emit('onFinal', ev.final);
            if (ev.error) this._emit('onError', ev.error);
            if (ev.end && !ev.auto) this._emit('onEnd');
          });
          await this.engine.start({ lang: this.lang });
          if (!this.active) { try { await this.engine.stop(); } catch (e2) {} return; }
          this._emit('onState', 'listening');
          return;
        }

        // 本地模式：先预热模型（首次下载会耗时，进度经 onModelProgress 上报），
        // 再开启麦克风。避免用户说完话后才触发模型下载导致超时/无反馈。
        this._emit('onState', 'initializing');
        try {
          await this.engine.initialize();
          const cb2 = global.AsrKit.circuitBreaker;
          if (cb2) cb2.markSuccess('whisper'); // 成功 → 复位熔断计数
        } catch (e) {
          console.warn('[asr] Whisper 模型预热失败，回退在线或报错:', e);
          const cb2 = global.AsrKit.circuitBreaker;
          if (cb2) cb2.markFailure('whisper', e && e.message); // 失败 → 累计,到阈值即熔断
          // 预热失败：若有在线授权则降级，否则上抛规范错误码（防止原始 Error 泄漏给 UI）
          // 隐私门：LOCAL_ONLY 下即使 allowOnline=true 也绝不启用 WebSpeech
          if (this.allowOnline && this._privacyAllowsOnline() && global.AsrKit.webspeechSupported) {
            this.engine = new global.AsrKit.WebSpeechEngine();
            this.mode = 'online';
            this.engine.setCallback((ev) => {
              if (ev.interim) this._emit('onInterim', ev.interim);
              if (ev.final) this._emit('onFinal', ev.final);
              if (ev.error) this._emit('onError', ev.error);
              if (ev.end && !ev.auto) this._emit('onEnd');
            });
            await this.engine.start({ lang: this.lang });
            if (!this.active) { try { await this.engine.stop(); } catch (e2) {} return; }
            this._emit('onState', 'listening');
            return;
          }
          const err = new Error(ERR.MODEL_LOAD_FAILED);
          err.cause = e;
          throw err;
        }
        if (!this.active) return;

        // AudioCapture + VAD
        this.capture = new global.AsrKit.audio.AudioCapture();
        this.vad = new global.AsrKit.vad.VadEngine();
        this.vad.onSpeechStart = () => this._emit('onState', 'speaking');
        this.vad.onSilence = () => this._emit('onState', 'listening');
        this.vad.onUtterance = (audio, startMs, endMs) => this._enqueue(audio, startMs, endMs);
        this.capture.onLevel = (rms) => this._emit('onLevel', rms);
        this.capture.onAudio = (chunk) => {
          if (!this.active) return;
          this.vad.push(chunk);
        };
        await this.capture.start();
        if (!this.active) { try { await this.capture.stop(); } catch (e2) {} this.capture = null; return; }
        this._emit('onState', 'listening');
      } catch (e) {
        this.active = false;
        throw e;
      }
    }

    async _enqueue(audio, startMs, endMs) {
      this.audioQueue.push({ audio, startMs, endMs });
      this._hasPendingUtterance = true;
      this._emit('onState', 'processing');
      if (this._speaking) return;
      this._speaking = true;
      while (this.audioQueue.length && this.active) {
        const item = this.audioQueue.shift();
        try {
          const r = await this.engine.transcribe(item.audio, { language: this.lang.split('-')[0] });
          if (!this.active) return;
          if (r && r.text) this._emit('onFinal', r.text);
          else this._emit('onError', ERR.NO_SPEECH);
        } catch (e) {
          console.error('[asr] transcribe error:', e);
          // 自动降级：推理失败（多为 OOM/设备丢失）→ 换 tiny 模型重试一次，避免直接结束会话
          const triedDowngrade = await this._tryDowngrade(item.audio);
          if (triedDowngrade) continue;
          if (this.active) {
            this._emit('onError', (e && e.message) || ERR.ASR_FAILED);
            // stop() 内部在 wasActive 时会 emit onEnd，无需重复触发
            await this.stop();
            return;
          }
        }
      }
      this._speaking = false;
      this._hasPendingUtterance = false;
      this._emit('onState', 'idle');
    }

    // 推理失败 → 降级到 whisper-tiny 重试一次；成功返回 true
    async _tryDowngrade(audio) {
      try {
        if (this.mode !== 'local' || !this.engine) return false;
        const cur = this.engine.modelName || '';
        if (String(cur).includes('whisper-tiny')) return false; // 已是最小模型
        console.warn('[asr] 推理失败，降级 whisper-tiny 重试');
        const tiny = global.AsrKit.modelManager.resolvePlan('low');
        const tinyEngine = new global.AsrKit.WhisperEngine({
          device: this.opts.device || 'auto',
          dtype: tiny.dtype,
          modelRepo: tiny.baseRepo,
          language: this.lang.split('-')[0],
          checkModelFile: true,
        });
        await tinyEngine.initialize();
        const r = await tinyEngine.transcribe(audio, { language: this.lang.split('-')[0] });
        if (r && r.text) {
          // 降级成功：替换当前引擎，后续句子用 tiny
          try { await this.engine.dispose(); } catch (e) {}
          this.engine = tinyEngine;
          this._emit('onError', ERR.OUT_OF_MEMORY); // 提示已降级（UI 显示"已切换到兼容模式"）
          this._emit('onFinal', r.text);
          return true;
        }
        return false;
      } catch (e2) {
        console.warn('[asr] 降级 tiny 也失败:', e2);
        return false;
      }
    }

    /** 用户主动停止（幂等：并发调用共享同一 Promise，杜绝 stop 之间互相打架） */
    async stop() {
      if (this.stopping) return this.stopPromise;
      this.stopping = true;
      this.stopPromise = this._stopInternal().finally(() => {
        this.stopping = false;
        this.stopPromise = null;
      });
      return this.stopPromise;
    }

    async _stopInternal() {
      const wasActive = this.active;
      const hadPending = this._hasPendingUtterance;
      this.active = false;
      if (this.vad && hadPending) {
        const leftover = this.vad.flush();
        if (leftover) {
          try {
            const r = await this.engine.transcribe(leftover, { language: this.lang.split('-')[0] });
            if (r && r.text) this._emit('onFinal', r.text);
          } catch (e) { console.error('[asr] flush transcribe error:', e); }
        }
      }
      if (this.capture) { await this.capture.stop(); this.capture = null; }
      if (this.mode === 'online' && this.engine) { await this.engine.stop(); }
      this.vad = null;
      this._speaking = false;
      this._hasPendingUtterance = false;
      this.audioQueue = [];
      if (wasActive) this._emit('onEnd');
    }

    async dispose() {
      await this.stop();
      if (this.engine && this.mode === 'local') { try { await this.engine.dispose(); } catch (e) {} }
      this.engine = null;
    }
  }

  global.AsrKit = global.AsrKit || {};
  global.AsrKit.AsrManager = AsrManager;
})(typeof window !== 'undefined' ? window : globalThis);
